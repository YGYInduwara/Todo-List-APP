package com.example.myapplicationnewtaskmanagement

data class Note(val id: Int, val title:String, val content:String)
